function [M] = DissimilarityMatrix(X)
% calculate the DissimilarityMatrixm of data X ,X is train_x
% X with size(row,N,column)

[row,N,column] = size(X);

for i=1:N
    norm_Xi = sqrt(sum(sum(X(:,i,:).^2)));
    X(:,i,:) = X(:,i,:)/norm_Xi;
end
sigma = 0;

for i=1:N
    for j=1:N
        sigma = sigma + (1 - abs(sum(sum(X(:,i,:).*X(:,j,:)))));
    end
end

sigma = sigma/N;

M = zeros(N,N);
for i=1:N
    for j=1:i
        temp = abs(sum(sum(X(:,i,:).*X(:,j,:))));
        M(i,j) = 1 - exp((temp-1)/sigma);
        M(j,i) = 1 - exp((temp-1)/sigma);
    end
end
