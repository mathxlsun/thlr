function [rec_loss] = rec_loss(Z,X)
% 计算重构损失
% 输入:自表达系数Z,原始数据集X
% 输出:重构损失 ||X-XZ||2F
[n1,n2,n3] = size(X);
Zhat = fft(Z,[],3);
Xhat = fft(X,[],3);
rec_X = zeros(n1,n2,n3);
for i=1:n3
    rec_X(:,:,i) = Xhat(:,:,i)*Zhat(:,:,i);
end

rec_X = ifft(rec_X,[],3);

rec_loss = sqrt(sum(sum(sum((rec_X - X).^2))));

end

