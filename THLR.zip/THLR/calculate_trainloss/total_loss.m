function [total_loss] = total_loss(C,M,Q,X,Z,lambda1,lambda2)
% 计算模型总损失
% 输入:亲和矩阵M,自表达系数Z,原始数据X
% 输出:训练总损失

TNN = nuclear_norm(C);
rec = rec_loss(Z,X);
MQ = sum(sum(sum(abs(M.*Q))));

total_loss = TNN + lambda1*MQ + lambda2*rec;

end

