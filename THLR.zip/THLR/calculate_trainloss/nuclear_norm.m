function [TNN] = nuclear_norm(Z)
% 计算张量Z的核范数
% 输入:三维张量Z
% 输出:Z的核范数(对Z的前切片奇异值之和求和)

TNN = 0;

for i=1:size(Z,3)
    si = svd(Z(:,:,i));
    TNN = TNN + sum(si);
end 


end

